import { hydrateRoot } from 'react-dom/client';
import Home from '../app/page';
import '../app/globals.css';

hydrateRoot(document.getElementById('root')!, <Home
  assetsBase="/"
  contactEndpoint="https://tianjiangao.darkraven32.chatgpt.site/api/contact"
  inboxHref="https://tianjiangao.darkraven32.chatgpt.site/inbox"
/>);
