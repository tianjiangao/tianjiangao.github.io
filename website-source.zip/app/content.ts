export const content = {
  "zh": {
    "nav": [
      "关于",
      "研究与实践",
      "经历",
      "联系"
    ],
    "portrait": "高天健的个人头像",
    "projects": [
      {
        "type": "产业与公司研究",
        "title": "一级市场产业与公司研究",
        "status": "实习研究",
        "summary": "在博佳资本支持储能、超算、硅片、创新药与灵巧手等方向的研究，梳理产业链、竞争格局和技术路径。",
        "result": "参与研究报告撰写与大模型公司实地调研，整理产品定位、客户场景、商业化路径和交付模式。",
        "detail": "通过公开资料检索、公司信息整理和业务模式对比，为内部项目分析与讨论提供研究材料。我的工作集中于产业与公司研究支持。",
        "tags": [
          "产业链",
          "商业模式",
          "竞争格局"
        ],
        "label": "FINANCE"
      },
      {
        "type": "机器人部署与调试",
        "category": 1,
        "title": "银行场景机器人导览系统",
        "status": "部署调试阶段",
        "summary": "参与银行场景导览系统部署与联调，在 NVIDIA Jetson Orin 平台检查 SLAM 与激光雷达节点，查看里程计与点云话题。",
        "result": "排查 ROS 2 / DDS 通信问题，通过切换 CycloneDDS 恢复话题通信。",
        "detail": "配合研发团队进行系统调试、网络配置与问题隔离；参与建图流程和地图保存接口调试。职责为实习阶段的技术支持与联调，项目目前仍处于部署调试阶段。",
        "tags": [
          "ROS 2",
          "SLAM",
          "Jetson Orin",
          "CycloneDDS"
        ],
        "art": "robot",
        "label": "01 / ROBOTICS"
      },
      {
        "type": "产业与竞品研究",
        "category": 2,
        "title": "海外预测性维护市场调研",
        "status": "专题研究",
        "summary": "围绕海外无线振动传感器与预测性维护方案，对比主要厂商、产品形态、商业模式和国际化路径。",
        "result": "形成专题报告，向国际市场负责人汇报，为市场定位和竞品分析提供参考。",
        "detail": "检索公开资料，整理全球通信方案、市场进入路径与工业客户需求，将产品能力与应用场景对应。研究属于实习工作成果，网站不展示内部报告或客户资料。",
        "tags": [
          "Industry Research",
          "Predictive Maintenance",
          "Market Analysis"
        ],
        "art": "market",
        "label": "02 / INDUSTRY"
      },
      {
        "type": "能源与智能算法研究",
        "category": 3,
        "title": "全钒液流电池健康度估计",
        "status": "竞赛研究",
        "summary": "参与节能减排竞赛项目，围绕机理协同粒子群优化算法改进极限学习机（ELM）的电池健康度估计方法开展研究。",
        "result": "参与文献调研、资料整理和研究分析，理解能源系统与智能算法的结合方式。",
        "detail": "研究关注全钒液流电池的健康状态估计，以及机理信息与智能算法的结合。我的参与内容为文献调研、资料整理与研究分析，梳理方法原理和相关研究路径。",
        "tags": [
          "Energy Systems",
          "PSO",
          "ELM",
          "Literature Review"
        ],
        "art": "battery",
        "label": "03 / ENERGY"
      },
      {
        "type": "工业设备与维护研究",
        "category": 2,
        "title": "工业机器人预测性维护",
        "status": "研究分析",
        "summary": "梳理减速器、轴承、电机和编码器等部件的故障模式，以及振动、温度、电流和控制器日志等数据来源。",
        "result": "分析从异常识别、故障诊断到维护执行的业务闭环，连接设备数据与维护需求。",
        "detail": "重点整理不同故障模式对应的数据来源与诊断思路，研究维护策略如何与工业现场业务衔接，并梳理异常发现、问题诊断与维护执行之间的信息需求。",
        "tags": [
          "Robotics",
          "Condition Monitoring",
          "Diagnostics"
        ],
        "art": "maintenance",
        "label": "04 / SYSTEMS"
      }
    ],
    "contribution": "我的贡献",
    "experience": [
      [
        "宇树科技",
        "北京研发 · SLAM 实习生",
        "2026.09 — 至今",
        "参与银行导览系统部署与联调、SLAM 与雷达节点检查，以及机器人网络和 ROS 2 / DDS 通信排查。",
        [
          "SLAM",
          "ROS 2",
          "Jetson Orin"
        ]
      ],
      [
        "宇树科技",
        "杭州 · 技术支持实习生",
        "2026.07 — 2026.09",
        "支持 A2 四足机器人二次开发与基础排障，整理操作和开发资料，梳理电力、石化、矿山等工业巡检场景的部署需求。",
        [
          "Unitree SDK2",
          "Linux",
          "Technical Support"
        ]
      ],
      [
        "博佳资本",
        "投资研究实习生",
        "2026.01 — 2026.02",
        "支持储能、超算、硅片、创新药与灵巧手方向的一级市场研究，参与大模型公司实地调研及研究材料整理。",
        [
          "Industry Research",
          "Commercialization"
        ]
      ],
      [
        "中控技术",
        "核电事业部 · 工业自动化实习生",
        "2025.07 — 2025.08",
        "参与 DCS / PLC 基础测试与整机联调，核查图纸与实物差异，记录问题并支持生产和测试环节复核。",
        [
          "DCS / PLC",
          "System Integration"
        ]
      ],
      [
        "博华科技",
        "国际市场部 · 国际市场实习生",
        "2025.01 — 2025.02",
        "参与工厂验收测试，协同国外客户与第三方监理完成资料确认和现场沟通；开展海外无线传感器与预测性维护市场调研。",
        [
          "FAT",
          "Market Research"
        ]
      ],
      [
        "博华科技",
        "顺义生产部 · 生产与测试实习生",
        "2024.07 — 2024.09",
        "参与板卡质检、组装与组态测试，使用万用表、示波器和振动台支持样机功能与可靠性测试。",
        [
          "Hardware Testing",
          "Quality Control"
        ]
      ],
      [
        "中信证券",
        "紫竹院营业部 · 财富管理实习生",
        "2024.01 — 2024.02",
        "支持客户需求沟通、产品介绍与开户推广，独立完成一次金融产品介绍会的资料准备和现场讲解。",
        [
          "Client Communication",
          "Presentation"
        ]
      ]
    ],
    "university": "北京工业大学",
    "degree": "本科 · 能源动力（新能源方向）",
    "minor": "辅修计算机",
    "personal": "课堂之外，我曾担任学院新生杯足球队队长，负责组队、训练安排与比赛协调。团队合作和临场沟通，也是我持续学习的一部分。",
    "skills": [
      [
        "编程与系统",
        "Python、C：基础编写、数据处理与调试；Linux / WSL 环境配置、进程与网络排查。"
      ],
      [
        "机器人技术",
        "ROS 2、DDS / CycloneDDS、Unitree SDK2；SLAM 与雷达节点检查、点云及里程计话题调试。"
      ],
      [
        "工业与硬件",
        "DCS / PLC 基础测试与联调；万用表、示波器、振动台、板卡测试与 FAT 支持。"
      ],
      [
        "研究与沟通",
        "行业研究、竞品分析、市场调研、客户沟通、报告整理；CET-6，可阅读英文技术资料并进行日常工作沟通。"
      ]
    ]
  },
  "en": {
    "nav": [
      "About",
      "Work",
      "Experience",
      "Contact"
    ],
    "portrait": "Portrait of Gao Eric Tianjian",
    "projects": [
      {
        "type": "Industry & company research",
        "title": "Primary-market industry & company research",
        "status": "Internship research",
        "summary": "Supported research across energy storage, supercomputing, silicon wafers, innovative medicines, and dexterous hands at Bojia Capital.",
        "result": "Contributed research materials and an on-site LLM-company visit, organizing product positioning, customer use cases, commercialization, and delivery models.",
        "detail": "Compared public information, company profiles, and business models to support internal project discussions. My role focused on research support.",
        "tags": [
          "Industry structure",
          "Business models",
          "Competition"
        ],
        "label": "FINANCE"
      },
      {
        "type": "ROBOT DEPLOYMENT & DEBUGGING",
        "category": 1,
        "title": "Robotic guidance in a bank environment",
        "status": "Deployment in progress",
        "summary": "Support deployment and system debugging on NVIDIA Jetson Orin, checking SLAM and LiDAR nodes, odometry, and point-cloud topics.",
        "result": "Restored topic connectivity by switching to CycloneDDS during ROS 2 / DDS communication troubleshooting.",
        "detail": "Collaborate with R&D engineers on system debugging, network setup, issue isolation, mapping, and map-save interfaces. My role is internship-level technical support and integration; the project remains in its deployment and debugging phase.",
        "tags": [
          "ROS 2",
          "SLAM",
          "Jetson Orin",
          "CycloneDDS"
        ],
        "art": "robot",
        "label": "01 / ROBOTICS"
      },
      {
        "type": "INDUSTRY & COMPETITIVE RESEARCH",
        "category": 2,
        "title": "Overseas predictive-maintenance market",
        "status": "Market research",
        "summary": "Compare overseas wireless vibration sensors and predictive-maintenance solutions across vendors, product forms, business models, and international expansion.",
        "result": "Prepared a research report and presented it to the international-market lead to support positioning and competitive analysis.",
        "detail": "Reviewed public information on global communication solutions, market-entry approaches, and industrial-customer requirements. This site describes my work without displaying internal reports or customer information.",
        "tags": [
          "Industry Research",
          "Predictive Maintenance",
          "Market Analysis"
        ],
        "art": "market",
        "label": "02 / INDUSTRY"
      },
      {
        "type": "ENERGY & INTELLIGENT ALGORITHMS",
        "category": 3,
        "title": "Flow-battery state-of-health research",
        "status": "Competition research",
        "summary": "Participated in research on a mechanism-informed particle-swarm-optimization approach to improving an extreme learning machine for vanadium redox flow battery health estimation.",
        "result": "Contributed literature review, information organization, and research analysis at the intersection of energy systems and intelligent algorithms.",
        "detail": "My contribution focused on literature review, organizing research information, and analyzing how mechanism-informed optimization connects with intelligent health estimation.",
        "tags": [
          "Energy Systems",
          "PSO",
          "ELM",
          "Literature Review"
        ],
        "art": "battery",
        "label": "03 / ENERGY"
      },
      {
        "type": "INDUSTRIAL SYSTEMS & MAINTENANCE",
        "category": 2,
        "title": "Industrial-robot predictive maintenance",
        "status": "Research analysis",
        "summary": "Map failure modes across reducers, bearings, motors, and encoders, alongside vibration, temperature, current, and controller-log data sources.",
        "result": "Analyzed the workflow from anomaly detection and fault diagnosis to maintenance execution.",
        "detail": "Organized the relationship between failure modes, data sources, and diagnostic approaches, examining how maintenance decisions connect to field operations and the information needed at each stage.",
        "tags": [
          "Robotics",
          "Condition Monitoring",
          "Diagnostics"
        ],
        "art": "maintenance",
        "label": "04 / SYSTEMS"
      }
    ],
    "contribution": "My contribution",
    "experience": [
      [
        "Unitree Robotics",
        "Beijing · SLAM R&D Intern",
        "Sep 2026 — Present",
        "Support bank-guidance robot deployment, SLAM and LiDAR node checks, robot networking, and ROS 2 / DDS communication troubleshooting.",
        [
          "SLAM",
          "ROS 2",
          "Jetson Orin"
        ]
      ],
      [
        "Unitree Robotics",
        "Hangzhou · Technical Support Intern",
        "Jul 2026 — Sep 2026",
        "Support SDK-based A2 quadruped application development and troubleshooting. Document operation and development procedures, and review deployment needs for industrial inspection.",
        [
          "Unitree SDK2",
          "Linux",
          "Technical Support"
        ]
      ],
      [
        "Bojia Capital",
        "Investment Research Intern",
        "Jan 2026 — Feb 2026",
        "Support primary-market research on energy storage, supercomputing, silicon wafers, innovative medicines, and dexterous hands. Participate in an on-site visit to an LLM company and organize research materials.",
        [
          "Industry Research",
          "Commercialization"
        ]
      ],
      [
        "SUPCON Technology",
        "Nuclear Power Unit · Automation Intern",
        "Jul 2025 — Aug 2025",
        "Perform basic DCS / PLC testing and system integration. Check drawings against physical assemblies and record issues for production and test teams.",
        [
          "DCS / PLC",
          "System Integration"
        ]
      ],
      [
        "Bohua Technology",
        "International Market Intern",
        "Jan 2025 — Feb 2025",
        "Support FAT with overseas customers and third-party inspectors, coordinate documentation, and research overseas wireless sensors and predictive-maintenance solutions.",
        [
          "FAT",
          "Market Research"
        ]
      ],
      [
        "Bohua Technology",
        "Production & Test Intern",
        "Jul 2024 — Sep 2024",
        "Support board inspection, assembly, software configuration checks, and prototype testing with multimeters, oscilloscopes, and vibration test benches.",
        [
          "Hardware Testing",
          "Quality Control"
        ]
      ],
      [
        "CITIC Securities",
        "Wealth Management Intern",
        "Jan 2024 — Feb 2024",
        "Support customer communication, product introduction, and account-opening activities. Independently prepare and present one financial-product introduction session.",
        [
          "Client Communication",
          "Presentation"
        ]
      ]
    ],
    "university": "Beijing University of Technology",
    "degree": "B.Eng. · Energy & Power Engineering (New Energy)",
    "minor": "Minor in Computer Science",
    "personal": "Outside the classroom, I captained my college’s freshmen football team, organizing training and matches. Teamwork and communication under pressure are also part of what I keep learning.",
    "skills": [
      [
        "Code & systems",
        "Python and C: basic programming, data processing, and debugging. Linux / WSL environment setup, process checks, and network troubleshooting."
      ],
      [
        "Robotics",
        "ROS 2, DDS / CycloneDDS, and Unitree SDK2. Basic SLAM and LiDAR node checks, point-cloud and odometry topic debugging."
      ],
      [
        "Industry & hardware",
        "Basic DCS / PLC testing and integration. Multimeters, oscilloscopes, vibration testing, board inspection, and FAT support."
      ],
      [
        "Research & communication",
        "Industry and competitor research, customer communication, and reports. Native Mandarin; CET-6 English, technical reading and day-to-day work communication."
      ]
    ]
  }
} as const;
