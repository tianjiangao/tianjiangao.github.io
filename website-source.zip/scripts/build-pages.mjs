import { readFile, writeFile, mkdir, cp, readdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';
import { build } from 'vite';
import react from '@vitejs/plugin-react';
import { renderToString } from 'react-dom/server';
import { createElement } from 'react';

const root = resolve(import.meta.dirname, '..');
const temporary = resolve(root, '.sites-runtime/pages-render');
const output = resolve(root, 'dist-pages');
await mkdir(temporary, { recursive: true });
for (const [source, target] of [['app/content.ts', 'content.mjs'], ['app/page.tsx', 'page.mjs']]) {
  const text = await readFile(resolve(root, source), 'utf8');
  const { outputText } = ts.transpileModule(text, {compilerOptions: {
    jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
  }});
  await writeFile(resolve(temporary, target), outputText.replace("from './content'", "from './content.mjs'"));
}
const { default: Home } = await import(pathToFileURL(resolve(temporary, 'page.mjs')).href);
const markup = renderToString(createElement(Home, {
  assetsBase: '/', contactEndpoint: 'https://tianjiangao.darkraven32.chatgpt.site/api/contact',
  inboxHref: 'https://tianjiangao.darkraven32.chatgpt.site/inbox',
}));
await writeFile(resolve(root, 'github-pages/index.html'), `<!doctype html>
<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>高天健 · Gao Eric Tianjian</title>
<meta name="description" content="北京工业大学学生，能源动力专业、辅修计算机。关注 AI、金融与商业分析，希望成为 polymath。做对的事情，把事情做对。">
<link rel="canonical" href="https://tianjiangao.github.io/"><link rel="icon" href="/favicon.svg">
<meta property="og:title" content="高天健 · Gao Eric Tianjian"><meta property="og:type" content="website"><meta property="og:url" content="https://tianjiangao.github.io/"><meta property="og:image" content="https://tianjiangao.github.io/portrait.jpeg">
<meta name="theme-color" content="#fcfbf8"><link rel="preload" href="/wenkai.woff2" as="font" type="font/woff2" crossorigin>
</head><body><div id="root">${markup}</div><script type="module" src="./main.tsx"></script></body></html>`);
await build({ configFile: false, root: resolve(root, 'github-pages'), publicDir: false, plugins:[react()],
  build:{outDir:output,emptyOutDir:true,assetsDir:'',rollupOptions:{output:{
    entryFileNames:'site.js',chunkFileNames:'chunk-[name].js',assetFileNames:'site.[ext]',
  }}},
});
// GitHub's browser upload keeps these deployment assets at repository root.
for (const file of await readdir(resolve(root,'public/assets'))) {
  await cp(resolve(root,'public/assets',file),resolve(output,file));
}
const css = await readFile(resolve(output,'site.css'),'utf8');
await writeFile(resolve(output,'site.css'),css.replaceAll('/assets/','/'));
await writeFile(resolve(output,'.nojekyll'),'');
await writeFile(resolve(output,'robots.txt'),'User-agent: *\nAllow: /\nSitemap: https://tianjiangao.github.io/sitemap.xml\n');
await writeFile(resolve(output,'sitemap.xml'),'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://tianjiangao.github.io/</loc></url></urlset>');
await writeFile(resolve(output,'README.md'),`# Gao Eric Tianjian · 高天健

Personal website: https://tianjiangao.github.io/

This repository hosts the pre-rendered React frontend on GitHub Pages. Chinese/English views, dark mode, résumé downloads, the scroll viewer, and the contact form work here. Contact submissions are stored by the existing Sites backend; the owner inbox requires sign-in.

The included website-source.zip contains the frontend source and assets. To rebuild, extract it, install Node.js 22+, run npm install, then npm run build:pages. Publish the contents of dist-pages to this repository's main branch. Deployment uses GitHub Pages from main / root.

Artwork: Mi Youren, Cloudy Mountains, Southern Song dynasty. The Metropolitan Museum of Art, public domain. See ART-CREDITS.txt. Fonts retain their respective SIL Open Font License notices. Personal photographs and résumé content belong to Gao Eric Tianjian.
`);
await rm(resolve(root,'github-pages/index.html'));
console.log('GitHub Pages build ready:',output);
